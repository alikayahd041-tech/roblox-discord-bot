# Roblox Discord Çoklu Grup Yönetim Botu

## Kurulu başlangıç sistemleri
- 7 Roblox grubunu başlangıçta veritabanına ekler.
- Slash komutları: ping, yardim, gruplar, grup-ekle, grup-sil, dogrula, roblox-hesabim, oyuncu-bilgi, rutbeler, rutbe-degistir, rutbe-terfi, rutbe-tenzil.
- Branş istekleri: brans-istek, brans-istekler, brans-onayla, brans-reddet.
- Kayıt: kayit, kayit-bilgi.
- Kurallar: kurallar, kural-ekle.
- Otomatik yanıt: oto-yanit-ekle, oto-yanit-sil, oto-yanitlar.
- Duyuru, işlem logu, son işlemler, sunucu ban/unban.
- Bilet paneli, bilet açma düğmesi, kapatma ve kullanıcı ekleme.
- SQLite kalıcı veri dosyası.

## Kurulum
1. Python 3.10 veya üstü gerekir.
2. `python -m pip install -r requirements.txt`
3. `.env.example` dosyasını `.env` olarak kopyala ve Discord token + Roblox Open Cloud API anahtarını gir.
4. Discord Developer Portal'dan botu `bot` ve `applications.commands` izinleriyle sunucuya ekle.
5. `python bot.py` ile çalıştır.

## Güvenlik ve önemli sınırlamalar
- `.env` dosyasını GitHub'a yükleme. Token/API anahtarını kimseye gönderme.
- `/dogrula` Roblox kullanıcı adını eşleştirir ama hesabın sahipliğini kanıtlamaz; gerçek doğrulama için profile doğrulama kodu/claim sistemi eklenmelidir.
- Roblox rütbe değişimi Open Cloud endpointleri, API anahtarının kapsamı, hedef grupların anahtara eklenmesi ve rol hiyerarşisine bağlıdır. Önce test grubunda dene.
- Botu 7/24 çalıştırmak için uygun bir host gerekir. Ücretsiz hostların uyku, kaynak veya süre sınırları olabilir.
- Bu sürümde otomatik Roblox hesap doğrulama, gerçek Roblox grup üyelik senkronizasyonu, Discord rol eşleme, ayrıntılı başvuru paneli ve çoklu kategori biletleri henüz tam uygulanmış değildir. Bunlar ek geliştirme ister.
